package com.example.secondactivity.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.secondactivity.R
import com.example.secondactivity.navegation.AppNav
import com.example.secondactivity.navegation.AppNav.Primer.route

@Composable
fun Tercer ( navController: NavController){
    Scaffold (
        topBar = {
            TopAppBar() {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "." , modifier = Modifier.clickable{navController.navigate(route = AppNav.Primer.route)})
            }
        }
            ) {
        TercerBodyContent(navController)
    }
}
@Composable
fun TercerBodyContent(navController: NavController){

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        //Image(
            //modifier = Modifier.size(100.dp),
            //contentDescription = "Android",
            //painter = painterResource(R.drawable.brayan)
        //)
        Text(text = "Pagina Tercera 🐱🐱🐰🎊" )
        Spacer(modifier = Modifier
            .width(8.dp)
            .height(5.dp))
        Button(onClick = {
            navController.navigate(route = AppNav.Primer.route)
        }) {
            Text(text = "Primer Pagina")
        }
        Button(onClick = {
            navController.navigate(route = AppNav.Segundo.route)
        }) {
            Text(text = "Segunda Pagina")
        }
    }
}