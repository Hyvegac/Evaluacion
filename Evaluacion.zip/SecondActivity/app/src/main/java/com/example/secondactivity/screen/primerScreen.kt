package com.example.secondactivity.screen

import android.bluetooth.BluetoothA2dp
import android.text.style.BackgroundColorSpan
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.secondactivity.R
import com.example.secondactivity.navegation.AppNav
import com.example.secondactivity.navegation.AppNavegation

@Composable
fun Primer ( navController: NavController){
    Scaffold (
        topBar = {
            TopAppBar(backgroundColor = Color.Cyan) {
                Icon(imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Que hace",
                    modifier = Modifier.clickable { navController.navigate(route = AppNav.Segundo.route) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Menu", color = Color.Black,
                    modifier = Modifier.clickable { navController.navigate(route = AppNav.Segundo.route) })
                Spacer(modifier = Modifier
                    .width(8.dp)
                    .height(5.dp))
                Text(text = "Recibos", color = Color.Black,
                    modifier = Modifier.clickable { navController.navigate(route = AppNav.Tercer.route) })
            }
        }
            ){
        BodyContent(navController)
    }
}
@Composable
fun BodyContent(navController: NavController){
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Image(
            modifier = Modifier.size(200.dp),
            contentDescription = "Android",
            painter = painterResource(R.drawable.android)
        )
        Spacer(modifier = Modifier
            .width(8.dp)
            .height(5.dp))
        Text(text = "Acerca de nuestro restaurante:" +
                "\n"+
                "Establecimiento público en el que se sirven comidas, en menú o a la carta, a precios estipulados y a unas horas indicadas.\n" +
                "\n" +
                "A 50 años de haber comenzado su historia en México, Larousse ha construido un fondo editorial importante de cocina de México y el mundo. Nuestra empresa es una editorial conocida en muchos países del mundo por dos de sus pilares: los diccionarios y los libros de cocina.\n"  )
        Button(colors = ButtonDefaults.buttonColors(backgroundColor = Color.Green), onClick = {
            navController.navigate(route = AppNav.Segundo.route)
        }) {
            Text(text = "Inicio")
        }
    }
    Spacer(modifier = Modifier
        .width(8.dp)
        .height(5.dp))
}

//Para saber los estados debo hacer una variable tipo remember