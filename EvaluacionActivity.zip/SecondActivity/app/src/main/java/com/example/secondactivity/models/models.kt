package com.example.secondactivity.models


data class Receta(
    var nombre :String,
    var preparacion :String,
    var foto : Int
)