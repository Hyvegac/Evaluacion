package com.example.secondactivity.navegation

sealed class AppNav( val route: String){
    object Primer : AppNav(route = "primerScreen")
    object Segundo :AppNav(route = "segundoScreen")
    object Tercer :AppNav(route = "tercerScreen")

}
