package com.example.secondactivity.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.secondactivity.models.receta
import com.example.secondactivity.navegation.AppNav

@Composable
fun Segundo ( navController: NavController){
    Scaffold {
        SegundoBodyContent(navController)
    }
}
@Composable
fun SegundoBodyContent(navController: NavController){
    Column(){
        var datos = receta
        var estados by remember { mutableStateOf(false) }
        for (i in datos){
            Row(modifier = Modifier.clickable{estados = !estados}){
                Image(painter = painterResource(id = i.foto), contentDescription = "D", modifier = Modifier
                    .width(50.dp)
                    .height(50.dp))
                Column() {
                    Text(text = "${i.nombre}")
                    Text(text = "${i.preparacion}", maxLines = if (estados) Int.MAX_VALUE else 2)
                }
            }
        }


//        Image(
//            modifier = Modifier.size(100.dp),
//            contentDescription = "Android",
//            painter = painterResource(R.drawable.camilo)
//        )

        Spacer(modifier = Modifier
            .width(8.dp)
            .height(5.dp))
        Button(onClick = {
            navController.navigate(route = AppNav.Tercer.route)
        }) {
            Text(text = "PAGAR$")
        }
        Button(onClick = {
            navController.navigate(route = AppNav.Primer.route)
        }) {
            Text(text = "REGRESAR⬅️")
        }
    }
}

