package com.example.secondactivity.navegation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.secondactivity.screen.Primer
import com.example.secondactivity.screen.Segundo
import com.example.secondactivity.screen.Tercer
import com.example.secondactivity.screen.Tercer
@Composable
fun AppNavegation(){
    val navController = rememberNavController( )
    NavHost(
        navController = navController,
        startDestination = AppNav.Primer.route
    ){
        composable( route = AppNav.Primer.route){
            Primer(navController)
        }
        composable( route = AppNav.Segundo.route){
            Segundo(navController)
        }
        composable( route = AppNav.Tercer.route){
            Tercer(navController)
        }

    }
}